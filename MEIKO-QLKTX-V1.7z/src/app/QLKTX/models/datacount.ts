export class datacount{
    public  countphongtrong : number   ;
    public  countphongdung :number    ;
    public  sumphong :    number;
    public  countgiuongtrong :number    ;
    public  countgiuongdung :number    ;
    public  sumgiuong :  number  ;
}