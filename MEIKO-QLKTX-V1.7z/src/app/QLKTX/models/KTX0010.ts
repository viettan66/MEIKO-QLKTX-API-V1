import { KTX0011 } from './KTX0011';

export class KTX0010{
    public  KTX0010_ID : number   ;
    public  ten : string   ;
    public  WH0007_ID : string   ;
    public  maSanPham : string   ;
    public  giatien :string    ;
    public  ghichu :string    ;
    public  donvi :string    ;
    public  trangthai :boolean    ;
    public  check :boolean    ;
    public  thutu :  number  ;
    public  loai :  number  ;
    public  soluongmacdinh :  number  ;
    public  soluongfull :  number  ;
    public KTX0011 :KTX0011 
}