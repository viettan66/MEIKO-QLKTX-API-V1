import { KTX0020 } from './KTX0020';

export class KTX0022{
    public  KTX0022_ID : number   ;
    public  KTX0020_ID : number   ;
    public  HoTen :   string ;
    public  NamSinh :string    ;
    public  QuanHe : string   ;
    public  NgheNghiep : string   ;
    public  ChoOHienNay :string    ;
    public   KTX0020 :KTX0020    ;
}