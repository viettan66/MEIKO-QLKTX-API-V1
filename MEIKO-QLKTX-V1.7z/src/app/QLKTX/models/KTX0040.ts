export class KTX0040{
    public  KTX0040_ID : number   ; 
    public  tieude:  string  ; 
    public  image: string   ; 
    public  noidung:string    ; 
    public  ghichu: string   ; 
    public trangthai:boolean    ; 
    public  thutu:number    ; 
}