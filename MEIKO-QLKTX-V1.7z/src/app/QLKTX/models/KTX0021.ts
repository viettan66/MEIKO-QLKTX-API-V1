export class KTX0021{
    public  KTX0021_ID :number   ;
    public  KTX0020_ID :number   ;
    public  batdau :string   ;
    public  ketthuc :string   ;
    public  choo : string  ;
    public  nghenghiepnoilam :string   ;
    public   KTX0020 :KTX0021   ;
}