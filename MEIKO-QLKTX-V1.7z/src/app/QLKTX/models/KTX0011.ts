import { KTX0001 } from './KTX0001';
import { KTX0010 } from './KTX0010';

export class KTX0011{
    public  KTX0011_ID :number     ;
    public  KTX0001_ID :number     ;
    public  KTX0010_ID : number    ;
    public  soluong : number    ;
    public  ghichu :string     ;
    public  KTX0001 :KTX0001     ;
    public   KTX0010 :KTX0010     ;
}