import { KTX0031 } from './KTX0031';
import { KTX0023 } from './KTX0023';
import { KTX0020 } from './KTX0020';

export class valuesearch{
    public KTX0020 : KTX0020[]  ;
    public   KTX0023 :KTX0023[]    ;
    public  KTX0031 : KTX0031[]  ;
}