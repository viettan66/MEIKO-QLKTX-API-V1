import { Type } from '@angular/core';

export class result<Type> {
    data:Type;
    code:string;
    mess:string;
}