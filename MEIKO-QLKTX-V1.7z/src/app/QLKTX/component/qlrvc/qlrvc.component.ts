import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qlrvc',
  templateUrl: './qlrvc.component.html',
  styleUrls: ['./qlrvc.component.css']
})
export class QlrvcComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
