import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qlna',
  templateUrl: './qlna.component.html',
  styleUrls: ['./qlna.component.css']
})
export class QlnaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
