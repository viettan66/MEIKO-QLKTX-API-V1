import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-indon',
  templateUrl: './indon.component.html',
  styleUrls: ['./indon.component.css']
})
export class IndonComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
