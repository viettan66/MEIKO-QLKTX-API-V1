export class MKV9991{
    public id:string;
    public bophan_ma: string;
    public bophan_ten:string;
    public bophan_dienthoai: string;
    public bophan_diachi: string;
    public logo: string;
    public tinhtrang: boolean;
    public thutu: number;
    public idcha:string;
    public muc: string;
    public asoft: number;
    public congty_id: string
}