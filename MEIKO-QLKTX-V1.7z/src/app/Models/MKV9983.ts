import { MKV9982 } from './MKV9982';
import { MKV9999 } from './MKV9999';

export class MKV9983 {
    public  MKV9983_ID : number    ;
        public  TENNHOM: string    ;
        public  TINHTRANG :boolean      ;
}