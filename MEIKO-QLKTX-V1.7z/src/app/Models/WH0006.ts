export class WH0006{//http://192.84.100.207/adminapi/api/wh_admin/r1_loaisanphamgetbyselect
public WH0006_ID:string;
public tenLoaiSanPham:string;
public thuTu:number;
public trangThai:boolean;
}