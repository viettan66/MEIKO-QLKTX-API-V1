export class WH0007{
    public WH0007_ID:string;
    public WH0005_ID:string;
    public WH0006_ID:string;
    public WH0015_ID:string;
    public KTX0010_ID:number;
    public maSanPham:string;
    public tenSanPham:string;
    public moTa:string;
    public hanSuDung:any;
    public thoiGianBaoHanh:any;
    public trangThai:boolean;

    public soLuongTonKho: number;
    public soluongmacdinh: number;
    public soluongtinh: number;
    public IsKoubai: boolean;
    public tenDonViTinh: string;
    public tenLoaiSanPham: string;
    public tenNhaSanXuat: string;
    public updateDate: string;
    public maNhanVien: string;
    public hoVaTen: string;
    public WH0025_ID: string;
    public tenGiaKe: string;
    public maGiaKe: string;
    public check:boolean
}