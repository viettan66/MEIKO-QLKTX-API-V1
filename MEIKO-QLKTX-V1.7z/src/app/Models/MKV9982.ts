import { MKV9981 } from './MKV9981';
import { MKV9999 } from './MKV9999';
import { MKV9983 } from './MKV9983';

export class MKV9982 {
   public MKV9982_ID :   number  ;
    public  MKV9981_ID :number     ;
    public  MKV9983_ID :number     ;

    public   MKV9981 : MKV9981    ;
    public   MKV9983 : MKV9983    ;



}