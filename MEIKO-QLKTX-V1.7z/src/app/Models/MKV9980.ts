import { MKV9999 } from './MKV9999';
import { MKV9981 } from './MKV9981';

export class MKV9980 {
    public  MKV9980_ID : number     ;
    public  TENQUYEN : string     ;
    public  GHICHU :  string    ;
    public  TINHTRANG :    boolean  ;
    public  MKV9981 :MKV9981[]      ;
}